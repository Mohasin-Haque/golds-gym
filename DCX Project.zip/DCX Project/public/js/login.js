$(document).ready(function () {
    // Check if the user is already logged in from localStorage
    const username = localStorage.getItem('username');
    if (username) {
        $('#loginForm').hide();
        $('#welcome').show();
        $('#username').text(username);
    }

    // Handle login form submission
    $('#loginForm').on('submit', function (e) {
        e.preventDefault();

        const email = $('#email').val();
        const password = $('#password').val();

        $.ajax({
            url: 'http://127.0.0.1:3000/index.html',
            type: 'POST',
            data: JSON.stringify({ email, password }),
            contentType: 'application/json',
            success: function (response) {
                if (response.message === "Successfully Logged In") {
                    // Store username in localStorage for session persistence
                    localStorage.setItem('username', response.username);

                    // Hide login form and show welcome message
                    $('#loginForm').hide();
                    $('#welcome').show();
                    $('#username').text(response.username);

                    // Clear the input fields
                    $('#email').val('');
                    $('#password').val('');
                    $('#error-message').hide();
                }
            },
            error: function (xhr) {
                if (xhr.status === 401) {
                    $('#error-message').text('Invalid credentials').show();
                } else if (xhr.status === 0) {
                    $('#error-message').text('Unable to connect to the server').show();
                } else {
                    $('#error-message').text('An unexpected error occurred').show();
                }
            }
        });
    });

    // Password visibility toggle
    $('#toggle-password').click(function () {
        const passwordField = $('#password');
        const type = passwordField.attr('type') === 'password' ? 'text' : 'password';
        passwordField.attr('type', type);
        $(this).text(type === 'password' ? 'Show' : 'Hide');
    });

    // Handle logout functionality
    $('#logout-btn').click(function () {
        localStorage.removeItem('username');
        $('#loginForm').show();
        $('#welcome').hide();
    });
});
