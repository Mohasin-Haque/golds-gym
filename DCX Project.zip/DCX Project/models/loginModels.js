const db = require('../config/db');
const bcrypt = require('bcrypt');

const registerUser = (userDetails, callback) => {
    const { email, password } = userDetails;

    bcrypt.hash(password, 10, (err, hashedPassword) => {
        if (err) return callback(err, null);

        const sql = 'INSERT INTO loginuser (email, password) VALUES (?, ?)';
        db.query(sql, [email, hashedPassword], (err, result) => {
            if (err) return callback(err, null);
            callback(null, result);
        });
    });
};

// Validate user login
const validateUser = (email, password, callback) => {
    const sql = 'SELECT * FROM loginuser WHERE email = ?';
    db.query(sql, [email], (err, results) => {
        if (err) return callback(err, null);
        if (results.length === 0) {
            console.log('User not found');
            return callback(null, false); // User not found
        }

        const user = results[0];
        console.log('User found:', user); // Log the user for debugging

        bcrypt.compare(password, user.password, (err, isMatch) => {
            if (err) return callback(err, null);
            console.log('Password match:', isMatch); // Log password match result
            callback(null, isMatch); // Return true if passwords match
        });
    });
};

// Register new user with hashed password (if applicable)

module.exports = {
    validateUser,
    registerUser
};




// // models/loginModel.js
// const db = require('../config/db');
// const bcrypt = require('bcrypt');

// // Validate user login
// const validateUser = (email, password, callback) => {
//     const sql = 'SELECT * FROM loginuser WHERE email = ?';
//     db.query(sql, [email], (err, results) => {
//         if (err) return callback(err, null);
//         if (results.length === 0) return callback(null, false);

//         const user = results[0];
//         bcrypt.compare(password, user.password, (err, isMatch) => {
//             if (err) return callback(err, null);
//             callback(null, isMatch);
//         });
//     });
// };

// module.exports = {
//     validateUser
// };




// const db = require('../config/db');
// const bcrypt = require('bcrypt');

// // Validate user login
// const validateUser = (email, password, callback) => {
//     const sql = 'SELECT * FROM loginuser WHERE email = ?';
//     db.query(sql, [email], (err, results) => {
//         if (err) return callback(err, null);
//         if (results.length === 0) return callback(null, false);

//         const user = results[0];
//         bcrypt.compare(password, user.password, (err, isMatch) => {
//             if (err) return callback(err, null);
//             callback(null, isMatch);
//         });
//     });
// };

// // Register new user
// const registerUser = (userData, callback) => {
//     const sql = `INSERT INTO user_info (name, email, mobile, address1, address2, city, state, zip)
//                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

//     const values = [
//         userData.name,
//         userData.email,
//         userData.mobile,
//         userData.address1,
//         userData.address2 || null,
//         userData.city,
//         userData.state || null,
//         userData.zip,
//     ];

//     db.query(sql, values, callback);
// };

// module.exports = {
//     validateUser,
//     registerUser,
// };
