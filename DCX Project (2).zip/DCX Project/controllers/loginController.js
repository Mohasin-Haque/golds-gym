// // controllers/loginController.js
// const loginModel = require('../models/loginModels');

// // Controller to handle login
// const loginUser = (req, res) => {
//     const { email, password } = req.body;

//     if (!email || !password) {
//         return res.status(400).json({ message: "Email and password are required." });
//     }

//     loginModel.validateUser(email, password, (err, result) => {
//         if (err) {
//             return res.status(500).json({ error: err.message });
//         }
//         if (result) {
//             return res.status(200).json({ message: "Successfully Logged In" });
//         } else {
//             return res.status(401).json({ message: "Invalid Credentials" });
//         }
//     });
// };

// module.exports = {
//     loginUser
// };
// controllers/loginController.js
const loginModel = require('../models/loginModels');

// Controller to handle login
const loginUser = (req, res) => {
    const { email, password } = req.body;

    // Validate input
    if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required." });
    }

    // Validate user in the database
    loginModel.validateUser(email, password, (err, result) => {
        if (err) {
            console.error(err); // Log error
            return res.status(500).json({ error: err.message });
        }

        if (result) {
            // If password matches
            return res.status(200).json({ message: "Successfully Logged In", username: email });
        } else {
            // If credentials are incorrect
            return res.status(401).json({ message: "Invalid Credentials" });
        }
    });
};

module.exports = {
    loginUser
};




// // controllers/loginController.js
// const loginModel = require('../models/loginModels');

// // Controller to handle login
// const loginUser = (req, res) => {
//     const { email, password } = req.body;

//     if (!email || !password) {
//         return res.status(400).json({ message: "Email and password are required." });
//     }

//     loginModel.validateUser(email, password, (err, result) => {
//         if (err) {
//             return res.status(500).json({ error: err.message });
//         }
//         if (result) {
//             return res.status(200).json({ message: "Successfully Logged In" });
//         } else {
//             return res.status(401).json({ message: "Invalid Credentials" });
//         }
//     });
// };

// module.exports = {
//     loginUser
// };


// const userModel = require('../models/loginModels');

// // Controller to handle login
// const loginUser = (req, res) => {
//     const { email, password } = req.body;

//     if (!email || !password) {
//         return res.status(400).json({ message: "Email and password are required." });
//     }

//     userModel.validateUser(email, password, (err, result) => {
//         if (err) {
//             return res.status(500).json({ error: err.message });
//         }
//         if (result) {
//             return res.status(200).json({ message: "Successfully Logged In" });
//         } else {
//             return res.status(401).json({ message: "Invalid Credentials" });
//         }
//     });
// };

// // Controller to handle user registration
// const registerUser = (req, res) => {
//     const { name, email, mobile, address1, address2, city, state, zip } = req.body;

//     if (!name || !email || !mobile || !address1 || !city || !zip) {
//         return res.status(400).json({ message: "All fields except Address 2 and State are required." });
//     }

//     userModel.registerUser({ name, email, mobile, address1, address2, city, state, zip }, (err, result) => {
//         if (err) {
//             return res.status(500).json({ error: err.message });
//         }
//         res.status(201).json({ message: "Successfully Registered" });
//     });
// };

// module.exports = {
//     loginUser,
//     registerUser,
// };
