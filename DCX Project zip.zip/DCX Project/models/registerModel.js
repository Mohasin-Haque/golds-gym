// models/registerModel.js
const db = require('../config/db');

// Register new user
const registerUser = (userData, callback) => {
    const sql = `INSERT INTO user_info (name, email, mobile, address1, address2, city, state, zip)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

    const values = [
        userData.name,
        userData.email,
        userData.mobile,
        userData.address1,
        userData.address2 || null,
        userData.city,
        userData.state || null,
        userData.zip,
    ];

    db.query(sql, values, callback);
};

module.exports = {
    registerUser
};
