// // routes/loginRoutes.js
// const express = require('express');
// const router = express.Router();
// const loginController = require('../controllers/loginController'); // Renamed controller

// // Route for user login
// router.post('/', loginController.loginUser);

// module.exports = router;
// routes/loginRoutes.js
const express = require('express');
const router = express.Router();
const loginController = require('../controllers/loginController');

// Route for user login
router.post('/', loginController.loginUser);

module.exports = router;





// // routes/userRoutes.js
// const express = require('express');
// const router = express.Router();
// const userController = require('../controllers/loginController');

// // Route for user login
// router.post('/login', userController.loginUser);

// // Route for user registration
// router.post('/register', userController.registerUser);

// module.exports = router;

