// // server.js
// const express = require('express');
// const bodyParser = require('body-parser');
// const cors = require('cors');
// const path = require('path');

// // Import routes
// const loginRoutes = require('./routes/loginRoutes');

// // Initialize Express app
// const app = express();

// // Middleware
// app.use(cors());
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());

// // Serve static files (e.g., HTML, CSS, JS) from 'public' directory
// app.use(express.static(path.join(__dirname, 'public')));

// // Routes
// app.use('/login', loginRoutes); // Login-related routes

// // Default route (home page)
// app.get('/', (req, res) => {
//     res.sendFile(path.join(__dirname, 'public', 'index.html'));
// });

// // Handle 404 - Page Not Found
// app.use((req, res) => {
//     res.status(404).send('Page not found');
// });

// // Start the server
// const PORT = process.env.PORT || 3000;
// app.listen(PORT, () => {
//     console.log(`Server is running on http://localhost:${PORT}`);
// });


// server.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

// Import routes
const productRoutes = require('./routes/productRoutes');
const loginRoutes = require('./routes/loginRoutes'); // Import login routes
const registerRoutes = require('./routes/registerRoutes'); // Import register routes

// Initialize Express app
const app = express();

// Middleware
app.use(cors()); // Enable Cross-Origin Resource Sharing
app.use(bodyParser.urlencoded({ extended: true })); // Parse URL-encoded data
app.use(bodyParser.json()); // Parse JSON data

// Serve static files from the 'public' directory (for images, CSS, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use('/products', productRoutes); // Products-related routes
app.use('/login', loginRoutes); // Login-related routes
app.use('/register', registerRoutes); // Register-related routes

// Default route (home page)
app.get('/', (req, res) => {
    res.json({ message: 'Welcome to the DCX-App Store API!' });
});

// Handle 404 - Page Not Found
app.use((req, res) => {
    res.status(404).send('Page not found');
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});




// const express = require('express');
// const bodyParser = require('body-parser');
// const cors = require('cors');
// const path = require('path');

// // Import routes
// const productRoutes = require('./routes/productRoutes');
// const userRoutes = require('./routes/loginRoutes');

// // Initialize Express app
// const app = express();

// // Middleware
// app.use(cors()); // Enable Cross-Origin Resource Sharing
// app.use(bodyParser.urlencoded({ extended: true })); // Parse URL-encoded data
// app.use(bodyParser.json()); // Parse JSON data

// // Serve static files from the 'public' directory (for images, CSS, etc.)
// app.use(express.static(path.join(__dirname, 'public')));

// // Routes
// app.use('/products', productRoutes); // Products-related routes
// app.use('/users', userRoutes); // User-related routes (login, register, etc.)

// // Default route (home page)
// app.get('/', (req, res) => {
//     res.json({ message: 'Welcome to the DCX-App Store API!' });
// });

// // Handle 404 - Page Not Found
// app.use((req, res) => {
//     res.status(404).send('Page not found');
// });

// // Start the server
// const PORT = process.env.PORT || 3000;
// app.listen(PORT, () => {
//     console.log(`Server is running on http://localhost:${PORT}`);
// });