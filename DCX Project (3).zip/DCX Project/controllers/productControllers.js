// controllers/productController.js
const productModel = require('../models/productModels');

// Controller to get all products
const getAllProducts = (req, res) => {
    productModel.getAllProducts((err, products) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        else{
            console.log("Success");
        res.json(products);}
    });
};

module.exports = {
    getAllProducts,
};

