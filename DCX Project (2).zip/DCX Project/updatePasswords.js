const bcrypt = require('bcrypt');
const db = require('./config/db'); // Assuming config/db.js is where the DB connection is established

const users = [
    { email: 'Deepak@gmail.com', password: 'pass123' },
    { email: 'Sakshi@gmail.com', password: 'pass456' },
    { email: 'Nidhi@gmail.com', password: 'pass98' }
]; // Replace with your actual users' emails and plain passwords

// Loop through the users, hash their passwords, and update the database
users.forEach(user => {
    bcrypt.hash(user.password, 10, (err, hashedPassword) => {
        if (err) {
            console.error('Error hashing password', err);
        } else {
            const sql = 'UPDATE loginuser SET password = ? WHERE email = ?';
            db.query(sql, [hashedPassword, user.email], (err, result) => {
                if (err) {
                    console.error('Error updating password', err);
                } else {
                    console.log(`Password updated for ${user.email}`);
                }
            });
        }
    });
});
