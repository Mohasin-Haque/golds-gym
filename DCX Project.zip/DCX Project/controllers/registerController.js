// controllers/registerController.js
const registerModel = require('../models/registerModel');

// Controller to handle user registration
const registerUser = (req, res) => {
    const { name, email, mobile, address1, address2, city, state, zip } = req.body;

    if (!name || !email || !mobile || !address1 || !city || !zip) {
        return res.status(400).json({ message: "All fields except Address 2 and State are required." });
    }

    registerModel.registerUser({ name, email, mobile, address1, address2, city, state, zip }, (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(201).json({ message: "Successfully Registered" });
    });
};

module.exports = {
    registerUser
};
