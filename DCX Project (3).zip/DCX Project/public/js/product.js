// public/js/product.js
async function fetchProducts() {
    try {
        const response = await axios.get("/products");
        const products = response.data;

        // Call the function to populate the cards
        displayProducts(products);
    } catch (error) {
        console.error("Error fetching products:", error.message);
    }
}

// Function to display products as cards
function displayProducts(products) {
    const container = document.getElementById("product-container");
    container.innerHTML = "";

    products.forEach((product) => {
        const card = `
            <div class="col-md-4 d-flex justify-content-center mb-3">
                <div class="card shadow-sm">
                    <img
                        src="${product.image_url}"
                        class="card-img-top"
                        alt="${product.title}"
                        style="object-fit: cover; height: 200px;"
                    />
                    <div class="card-body">
                        <h5 class="card-title text-primary">${product.title}</h5>
                        <p class="card-text">${product.description}</p>
                        <p class="fw-bold">$${product.price}</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="rating">
                                ${generateStars(product.rating)}
                            </div>
                            <span>${product.reviews} Reviews</span>
                        </div>
                        <a href="#" class="btn mt-2 read_btn">Read More</a>
                    </div>
                </div>
            </div>
        `;
        container.innerHTML += card;
    });
}

// Function to generate star ratings
function generateStars(rating) {
    const fullStar = '<i class="fas fa-star"></i>';
    const emptyStar = '<i class="far fa-star"></i>';

    let stars = "";
    for (let i = 1; i <= 5; i++) {
        stars += i <= Math.floor(rating) ? fullStar : emptyStar;
    }
    return stars;
}

// Fetch products when the page loads
document.addEventListener("DOMContentLoaded", fetchProducts);


{/* <img src="https://i.ibb.co/5WGbnFc/microsoft-surface.jpg" alt="microsoft-surface" border="0">
<img src="https://i.ibb.co/wCR5Zf5/nikon-dslr-removebg-preview.png" alt="nikon-dslr-removebg-preview" border="0">
<img src="https://i.ibb.co/f8Rq0p8/oneplus.png" alt="oneplus" border="0">
<img src="https://i.ibb.co/Ms7rtBX/onepluswithoutbg.png" alt="onepluswithoutbg" border="0">
<img src="https://i.ibb.co/yNPM6q7/Playstation.jpg" alt="Playstation" border="0">
<img src="https://i.ibb.co/CvvqRhC/Samsung-galaxy.jpg" alt="Samsung-galaxy" border="0">
<img src="https://i.ibb.co/R7w4mxq/vizismart-tv.jpg" alt="vizismart-tv" border="0">
<img src="https://i.ibb.co/cDLYV56/Xbox-One.jpg" alt="Xbox-One" border="0">
<img src="https://i.ibb.co/2PCVyky/Apple.png" alt="Apple" border="0">
<img src="https://i.ibb.co/jw35sJs/img1.png" alt="img1" border="0">
<img src="https://i.ibb.co/nMfvczm/img2.png" alt="img2" border="0"></img> */}


// UPDATE `myapi`.`products` SET `image_url`='https://i.ibb.co/5WGbnFc/microsoft-surface.jpg' WHERE `id`='6';
// UPDATE `myapi`.`products` SET `image_url`='https://i.ibb.co/f8Rq0p8/oneplus.png' WHERE `id`='4';
// UPDATE `myapi`.`products` SET `image_url`='https://i.ibb.co/f8Rq0p8/oneplus.png' WHERE `id`='9';
// UPDATE `myapi`.`products` SET `image_url`='https://i.ibb.co/cDLYV56/Xbox-One.jpg' WHERE `id`='2';
// UPDATE `myapi`.`products` SET `image_url`='https://i.ibb.co/yNPM6q7/Playstation.jpg' WHERE `id`='3';
// UPDATE `myapi`.`products` SET `image_url`='https://i.ibb.co/yNPM6q7/Playstation.jpg' WHERE `id`='8';
// UPDATE `myapi`.`products` SET `image_url`='https://i.ibb.co/R7w4mxq/vizismart-tv.jpg' WHERE `id`='7';
// UPDATE `myapi`.`products` SET `image_url`='https://i.ibb.co/R7w4mxq/vizismart-tv.jpg' WHERE `id`='5';
