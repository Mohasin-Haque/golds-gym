// models/productModel.js
const db = require('../config/db');

// Fetch all products from the database
const getAllProducts = (callback) => {
    const sql = 'SELECT * FROM products';
    db.query(sql, (err, results) => {
        if (err) {
            return callback(err, null);
        }
        callback(null, results);
    });
};

module.exports = {
    getAllProducts,
};
