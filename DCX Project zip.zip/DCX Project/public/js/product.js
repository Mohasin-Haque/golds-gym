// public/js/product.js
async function fetchProducts() {
    try {
        const response = await axios.get("/products");
        const products = response.data;

        // Call the function to populate the cards
        displayProducts(products);
    } catch (error) {
        console.error("Error fetching products:", error.message);
    }
}

// Function to display products as cards
function displayProducts(products) {
    const container = document.getElementById("product-container");
    container.innerHTML = "";

    products.forEach((product) => {
        const card = `
            <div class="col-md-4 d-flex justify-content-center mb-3">
                <div class="card shadow-sm">
                    <img
                        src="${product.image_url}"
                        class="card-img-top"
                        alt="${product.title}"
                        style="object-fit: cover; height: 200px;"
                    />
                    <div class="card-body">
                        <h5 class="card-title text-primary">${product.title}</h5>
                        <p class="card-text">${product.description}</p>
                        <p class="fw-bold">$${product.price}</p>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="rating">
                                ${generateStars(product.rating)}
                            </div>
                            <span>${product.reviews} Reviews</span>
                        </div>
                        <a href="#" class="btn mt-2 read_btn">Read More</a>
                    </div>
                </div>
            </div>
        `;
        container.innerHTML += card;
    });
}

// Function to generate star ratings
function generateStars(rating) {
    const fullStar = '<i class="fas fa-star"></i>';
    const emptyStar = '<i class="far fa-star"></i>';

    let stars = "";
    for (let i = 1; i <= 5; i++) {
        stars += i <= Math.floor(rating) ? fullStar : emptyStar;
    }
    return stars;
}

// Fetch products when the page loads
document.addEventListener("DOMContentLoaded", fetchProducts);
