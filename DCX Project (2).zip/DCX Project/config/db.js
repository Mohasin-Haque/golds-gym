// const mysql = require('mysql');

// // Database configuration
// const db = mysql.createConnection({
//   host: 'localhost',
//   user: 'root',
//   password: '1234',
//   database: 'myapi',
// });

// // Connect to database
// db.connect((err) => {
//   if (err) {
//     console.error('Database connection failed:', err.message);
//     process.exit(1);
//   }
//   console.log('Connected to the database.');
// });

// module.exports = db;
// config/db.js
const mysql = require('mysql');

// Create a MySQL connection
const db = mysql.createConnection({
    host: 'localhost',      // Replace with your database host
    user: 'root',           // Replace with your database user
    password: '1234',           // Replace with your database password
    database: 'myapi'  // Replace with your database name
});

// Connect to MySQL database
db.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to the MySQL database');
});

module.exports = db;
